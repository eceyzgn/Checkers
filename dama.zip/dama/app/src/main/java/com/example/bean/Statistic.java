package com.example.bean;

public class Statistic {
    public int PLAYER;
    public int AI;

    public Statistic(int PLAYER, int AI) {
        this.PLAYER = PLAYER;
        this.AI = AI;
    }
}
