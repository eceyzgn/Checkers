package com.example.game;

public class Constant {
    public static final byte BLACK = -1;
    public static final byte NULL = 0;
    public static final byte WHITE = 1;
}
